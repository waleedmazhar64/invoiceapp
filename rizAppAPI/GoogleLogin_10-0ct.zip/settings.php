<?php

/* Google App Client Id */
define('CLIENT_ID', '1031490776744-7ct4qvkiqvgntprgqmstvbk2qc25uk79.apps.googleusercontent.com');

/* Google App Client Secret */
define('CLIENT_SECRET', 'v8WLDTHEPV8WtnW9l83w4MsM');

/* Google App Redirect Url */
define('CLIENT_REDIRECT_URL', 'http://demoopm.tk/gauth.php');

?>
